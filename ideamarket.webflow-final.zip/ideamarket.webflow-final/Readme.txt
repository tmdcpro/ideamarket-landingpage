To convert into React app, use AppFairy tool: https://medium.com/the-guild/how-to-create-a-react-app-out-of-a-webflow-project-309b696a0533
